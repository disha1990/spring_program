import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		
	ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
	System.out.println("first line");
	Employee obj=(Employee)context.getBean("emp");

    System.out.println(obj.getId());
	System.out.println(obj.getName());
	
	Employee obj1=(Employee)context.getBean("emp1");
	System.out.println(obj1.getName());
	
	Employee obj2=(Employee)context.getBean("emp2");
	System.out.println(obj2.getName());
	
	Employee obj3=(Employee)context.getBean("emp3");
	System.out.println(obj3.getName());
	}
}
